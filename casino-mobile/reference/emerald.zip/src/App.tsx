import React from 'react';
import { CasinoHome } from './pages/CasinoHome';
export function App() {
  return <CasinoHome />;
}